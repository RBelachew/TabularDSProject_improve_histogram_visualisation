# TDS project: improving histogram visualization: selecting optimal number of bins

Link of notebooks:


-Notebook 1 (optional with details on research phase) for observation https://colab.research.google.com/drive/1OTBbwNK72qAlZzHjouNPjd2iwRHjqYTU?usp=sharing

-Notebook 2 : explanation of our solution and evaluation https://colab.research.google.com/drive/1oKpaSYUkLNx1hXJHwsrKjabDS5xCW3mp?usp=sharing


**Requirement**: we only used classic modules and library that we used in class so there is no specific requirement for running the project.

**Run the project**: clone all the repository run notebook 2  (solution&eval) to see details on the implementation of the solution and evaluation of the method.
We used the python version of google colab which is Python 3.9.16


